#include <stdio.h>
#include <string.h>
#include <math.h>


 char s[101];
void removeCharacter(int i)
{

    for(;s[i]!='\0';)
    {
        s[i]=s[i+2];
        s[i+1]=s[i+3];
        i+=2;

    }
}

int main()
{
    int i=0,len=0;
    int size;	
    printf("Enter the size of string:");  
    scanf("%d",&size);
if(size>=1 && size <=100)
{
    s[size];
    printf("\nEnter the string of size %d:-",size);
    scanf("%s",s);
    for(;s[len]!='\0';len++);
    for(;i<len;)
    {
        if((s[i] == s[i+1] ) && (i >= 0) && s[i]!='\0')
        {
            removeCharacter(i);
            i--;
        }
        else
        {
            i++;
        }
    }
    if(s[0]=='\0')
       printf("\nEmpty String\n");
    else
       printf("%s\n",s);
}
else
{
printf("\nInvalid size\n");
}
    return 0;
}

#include <stdio.h>

void reverseBits(int);
int main()
{
    int a[10], number, i, j;
    printf("\n Enter the Number: ");
    scanf("%d", &number);
    reverseBits(number);

}

void reverseBits(int number)
{
     int a[10],i, j;
    for(i = 0; number > 0; i++)
    {
        a[i] = number % 2;
        number = number / 2;
    }
   
    printf("\n Before = ");
    for(j=i-1;j >= 0; j--) {
        printf(" %d ", a[j]);
    }
    printf("\n");
   
    printf("\n After = ");
    for(i=0;i <= 3; i++) {
        printf(" %d \n", a[i]);
    }
}


